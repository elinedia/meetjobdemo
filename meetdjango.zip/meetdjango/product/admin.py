from django.contrib import admin

# Register your models here.
from .models import Goods

class GoodsAdmin(admin.ModelAdmin):
	list_display = ('name','price','create_date') #自訂的顯示欄位
	#固定的變數名稱

admin.site.register(Goods,GoodsAdmin)