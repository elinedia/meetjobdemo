# -*- coding: utf-8 -*-
"""
Created on Thu Oct 13 20:58:12 2022

@author: watson
"""

import requests
from bs4 import BeautifulSoup

import db

from datetime import datetime as dt # 抓日期函式庫


today = dt.today() # 抓今天的日期格式

todayS = today.strftime('%Y-%m-%d') # 將設定好的日期格式轉換為字串使用


url = "https://www.ladyflavor.com/products"

payload = {'search':'貓砂'}

data = requests.get(url,params=payload).text

soup = BeautifulSoup(data,'html.parser')

goods = soup.find('div',class_='col-xs-12 ProductList-list')

allgoods = soup.find_all('div',class_='product-item')

print(goods)
print(allgoods)
cursor = db.conn.cursor()


for row in allgoods:
     link = row.get('href')
     #link = row.find('a').get('href')

     photo = row.find('div',class_='boxify-image-wrapper')
     #photo = photo.split()[0] # 切割，取第一個索引位置, 以空白    
     
     title = row.find('div',class_='title text-primary-color title-container ellipsis ')
     price = row.find('div',class_='global-primary dark-primary price  ')
     #price = price.replace('$','').replace(',','')
    
    
     print(link)
     print(photo)
     print(title)
     print(price)
     print()
    

     sql = "select * from goods where name='{}' ".format(title)
    
     cursor.execute(sql)
     db.conn.commit()
    
     if cursor.rowcount == 0 :  
         # 表示沒有該產品
         sql = "insert into goods(name,price,goods_url,photo_url,create_date,discount) values('{}','{}','{}','{}','{}','0')".format(title,price,link,photo,todayS)
         cursor.execute(sql)
         db.conn.commit()
        
    
db.conn.close()    
    
    
    




