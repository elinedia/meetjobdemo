# -*- coding: utf-8 -*-
"""
Created on Thu Jan  5 03:09:47 2023

@author: user
"""

import requests
from bs4 import BeautifulSoup

import db

from datetime import datetime as dt

url = "https://www.ladyflavor.com/products"

payload = {'search':'罐罐'}

data = requests.get(url,params=payload).text

soup = BeautifulSoup(data,'html.parser')

goods = soup.find('div',class_='col-xs-12 ProductList-list')

allgoods = soup.find_all('div',class_='product-item')




print(goods)
print(allgoods)