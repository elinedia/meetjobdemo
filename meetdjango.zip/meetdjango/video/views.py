from django.shortcuts import render

# Create your views here.

from .models import Vlogs

def video(request):
	data = Vlogs.objects.all().order_by('-create_date')

	return render(request,'video.html',locals())