# -*- coding: utf-8 -*-
"""
Created on Tue Dec  6 00:47:21 2022

@author: user
"""

import pymysql

dbsetting = {
    "host":"127.0.0.1",
    "port":3306,
    "user":"user1",
    "password":"ssassa",
    "db":"meetview",
    "charset":"utf8"
    
    }

conn = pymysql.connect(**dbsetting)